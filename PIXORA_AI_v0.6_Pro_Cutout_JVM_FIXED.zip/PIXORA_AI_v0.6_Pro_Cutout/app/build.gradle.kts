plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.pixora.ai"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.pixora.ai"
        minSdk = 23
        targetSdk = 35
        versionCode = 6
        versionName = "0.6"
    }

    // Keep Java bytecode target aligned with Kotlin JVM target.
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

kotlin {
    jvmToolchain(17)
}

tasks.withType<org.jetbrains.kotlin.gradle.tasks.KotlinCompile>().configureEach {
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.webkit:webkit:1.12.1")
}
