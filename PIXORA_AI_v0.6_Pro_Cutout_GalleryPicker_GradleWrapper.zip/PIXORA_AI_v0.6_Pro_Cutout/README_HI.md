# PIXORA AI v0.6 Pro Cutout

यह Android Studio का शुरुआती प्रोजेक्ट है। इसमें PIXORA AI v0.6 Pro Cutout का HTML फोटो-कटआउट इंटरफेस Android WebView में पैक किया गया है।

## फीचर्स
- फोन से फोटो चुनना (JPG / PNG / WEBP)
- AI Background Remove (पहली बार मॉडल इंटरनेट से डाउनलोड होता है)
- Transparent / White / Black background विकल्प
- PNG export और image size विकल्प
- Edge Smooth / Feather: cutout के किनारों को soften करना
- Hair Detail: बालों के आसपास alpha detail enhancement
- Original Colour Restore: original photo से रंग वापस blend करना
- Subject Zoom & Position: subject को zoom और left/right/up/down move करना

## Gallery Picker और Gradle Wrapper
- WebView में `<input type="file">` चुनने पर Android Gallery / Photo Picker खुलता है।
- प्रोजेक्ट में `gradlew`, `gradlew.bat` और Gradle 8.7 की wrapper properties शामिल हैं।
- Wrapper JAR ZIP में शामिल नहीं हो सका; पहली बार `./gradlew` (Windows: `gradlew.bat`) चलाने पर आधिकारिक Gradle server से अपने-आप डाउनलोड होगा। इसके लिए इंटरनेट जरूरी है।

## APK बनाने का तरीका
1. ZIP को Extract करें।
2. Android Studio में `PIXORA_AI_v0.6_Pro_Cutout` फ़ोल्डर खोलें।
3. Gradle Sync पूरा होने दें।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
5. APK `app/build/outputs/apk/debug/` में मिलेगा।

## जरूरी बातें
- यह ZIP Android Studio source project है, तैयार APK नहीं।
- AI मॉडल पहली बार डाउनलोड करने के लिए इंटरनेट जरूरी है।
- यह प्रोजेक्ट Android Studio और Android SDK के साथ build करना होगा।
