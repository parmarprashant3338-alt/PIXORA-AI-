plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.pixora.ai"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.pixora.ai"
        minSdk = 23
        targetSdk = 35
        versionCode = 6
        versionName = "0.6"
    }
}

dependencies {
    implementation("androidx.webkit:webkit:1.12.1")
}
