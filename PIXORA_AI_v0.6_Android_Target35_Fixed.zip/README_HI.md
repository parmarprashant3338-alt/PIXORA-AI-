# PIXORA AI v0.6 Android Starter

This is a free offline-first Android WebView photo editor project.

## Features
- Gallery photo import
- Brightness, contrast, saturation and simple filters
- Basic plain-colour background removal (NOT AI person segmentation)
- Solid background colours, original colour restore, edge soften
- PNG export (download behavior varies by Android WebView)

## Build on GitHub
Upload the extracted **project files and folders**, not the ZIP as one file, into a new GitHub repository. GitHub Actions workflow `.github/workflows/android.yml` builds a debug APK. Download it from the successful workflow's Artifacts section.

## Notes
- Java and Kotlin both target JVM 17, avoiding the earlier mismatch.
- The editor is an MVP, not the promised full AI hair cutout, zoom/position or video editor.
- APK compilation has not been verified in this environment.
